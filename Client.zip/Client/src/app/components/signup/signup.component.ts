import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { RouterModule, Routes, Router } from '@angular/router';
import { ValidationService } from '../../services/config/config.service';
import { UserService } from '../../services/user/user.service';
import { ToastrService } from 'ngx-toastr';
import { routerTransition } from '../../services/config/config.service';

@Component({
	selector: 'app-signup',
	templateUrl: './signup.component.html',
	styleUrls: ['./signup.component.css'],
	animations: [routerTransition()],
	host: { '[@routerTransition]': '' }
})
export class SignupComponent implements OnInit {
	signUpForm: FormGroup;
	constructor(private formBuilder: FormBuilder, private router: Router, private userService: UserService, private toastr: ToastrService) {
		this.signUpForm = this.formBuilder.group({
			username:['',[Validators.required]],
			email: ['', [Validators.required, ValidationService.emailValidator]],
			password: ['', [Validators.required, ValidationService.passwordValidator]]
		});
	}

	// Check if user already logged in
	ngOnInit() {
		if (localStorage.getItem('token')) {
			this.router.navigate(['/list']);
		}
	}

	// Initicate login
	doSignUp() {
		const login = this.userService.login(this.signUpForm.value);
		// this.success(login);
		this.userService.signUp(this.signUpForm.value).subscribe((res: any) => {	
			if (res.code === 200) {
				this.toastr.success('Success', res.message);
			  this.router.navigate(['/login']);
			} else {
				this.toastr.error('Failed', res.message);
			}
		})
	}

}
