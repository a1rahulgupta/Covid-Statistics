import { Component, OnInit, Inject, Input } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { CovidService } from 'src/app/services/covid-service/covid.service';

@Component({
  selector: 'app-covid-list',
  templateUrl: './covid-list.component.html',
  styleUrls: ['./covid-list.component.scss']
})
export class CovidListComponent implements OnInit {

  p: number = 1;

  rows = 10;
  allWorldCasesList: any = [];
  globalCases: any = {};
  toDayDate: any;
  constructor(private covidService: CovidService, private toastr: ToastrService) { }

  ngOnInit() {
    this.getAllCurrentActiveCases();
    
  }

  numberWithCommas(x) {
    if (x) {
      x = x.toString();
      var lastThree = x.substring(x.length - 3);
      var otherNumbers = x.substring(0, x.length - 3);
      if (otherNumbers != '')
        lastThree = ',' + lastThree;
      return otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;

    }

  }

  getAllCurrentActiveCases() {
    this.covidService.getAllCurrentActiveCases({}).subscribe((result) => {
      if (result) {
        this.globalCases = result.Global
        this.allWorldCasesList = result.Countries;
        this.toDayDate = result.Date;
      } else {
        this.toastr.error(result.message);
      }
    });
  }
}