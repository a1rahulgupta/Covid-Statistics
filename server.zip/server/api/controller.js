var express = require('express');
var mongoose = require('mongoose');
userModel = mongoose.model('userModel')
var jwt = require('jsonwebtoken');
var waterfall = require('async-waterfall');

exports.register = function (req, res) {
    var finalResponse = {};
    var userObj = {
        email: req.body.email,
        password: req.body.password,
        username: req.body.username

    };
    if (!userObj.username ||!userObj.email || !userObj.password) {
        res.json({
            code: 400,
            data: {},
            message: "Required Fields is missing"
        });
    } else {
        waterfall([
            function (callback) {
                userModel.findOne({ email: userObj.email, password: userObj.password, isDelete: false }, function (err, userExist) {
                    if (err) {
                        callback(err, false);
                    } else {
                        if (userExist) {
                            res.json({
                                code: 400,
                                data: {},
                                message: "This user is already exist. please try again with different user."
                            });
                        } else {
                            callback(null, finalResponse);
                        }
                    }
                });
            },

            function (finalResponse, callback) {
                var obj = {
                    email: userObj.email,
                    password: userObj.password,
                    username:userObj.username
                };

                var userRecord = new userModel(obj);
                userRecord.save(function (err, userData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        finalResponse.userData = userData;
                        callback(null, finalResponse);
                    }
                });

            }
        ], function (err, data) {
            console.log(err,data)
            if (err) {
                res.json({
                    code: 201,
                    data: {},
                    message: "Internal Error"
                });
            } else {
                res.json({
                    code: 200,
                    data: data,
                    message: "User Register Successfully"
                });
            }
        })
    }
}

exports.login = function (req, res) {
    var finalResponse = {};
    var condition = {};
    finalResponse.userData = {}
    var userObj = {
        email: req.body.email,
        password: req.body.password
    };
    if (!userObj.email || !userObj.password) {
        res.json({
            code: 400,
            data: {},
            message: "Required Fields is missing"
        });
    } else {
        waterfall([
            function (callback) {
                condition.email = userObj.email;
                condition.password = userObj.password;
                userModel.findOne(condition).exec(function (err, userData) {
                    if (err) {
                        callback(err, false);
                    } else {
                        if (!userData) {
                            res.json({
                                code: 406,
                                data: {},
                                message: "You have entered Invalid Username and Password"
                            });
                        } else {
                            const JwtToken = jwt.sign({
                                email: userData.email,
                                _id: userData._id
                            },
                                'secret',
                                {
                                    expiresIn: 60 * 60 * 24 * 15
                                });
                            finalResponse.token = JwtToken;
                            finalResponse.userData = userData;
                            callback(null, finalResponse);
                        }
                    }
                })
            }
        ], function (err, data) {
            if (err) {
                res.json({
                    code: 400,
                    data: {},
                    message: "Internal Error"
                });
            } else {
                res.json({
                    code: 200,
                    data: data,
                    message: "Login Successfully"
                });
            }
        });
    }
}
