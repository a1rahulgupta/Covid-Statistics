var config = {};

config.db = {};
config.webhost = 'http://localhost:3001/api/';
config.webUrl = 'http://localhost:3001/';
config.db.host = 'localhost';
config.db.name = 'covidApp';

module.exports = config;
