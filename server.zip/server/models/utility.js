'use strict';
var crypto = require('crypto');
var algorithm = 'aes-256-ctr';
var password = 'd6F3Efeq';
var path = require('path');
var async = require('async');
var fs = require("fs-extra");

var utility = {};

module.exports = utility;
